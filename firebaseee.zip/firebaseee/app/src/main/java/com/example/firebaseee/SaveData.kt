package com.example.firebaseee

class SaveData (val name : String, val course : String , val link : String) {

    constructor() : this("", "", "")

}